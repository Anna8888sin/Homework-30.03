import java.util.Scanner;

public class Main {
    /* 1 уровень сложности: Пользователь вводит, сколько лет он состоит в браке.
     Программа должна вывести, какая годовщина свадьбы будет у пользователя следующей
     (бумажная, ситцевая, чугунная, серебряная и.д.).
     Не обязательно указывать все годовщины, достаточно 10-15. */
    public static class WeddingAnniversary {
        public static void main(String[] args) {
            int[] years = {5, 10, 15, 20, 25, 30, 35, 40, 45, 50};
            String[] names = {"Деревянная", "Розовая", "Стеклянная", "Фарфоровая", "Серебряная", "Жемчужная", "Коралловая", "Рубиновая", "Сапфировая", "Золотая"};

            Scanner scanner = new Scanner(System.in);
            System.out.println("Введите, сколько лет вы состоите в браке: ");
            int yearsMarried = scanner.nextInt();

            int nextAnniversaryYear = 0;
            for (int year : years) {
                if (year > yearsMarried) {
                    nextAnniversaryYear = year;
                    break;
                }
            }

            if (nextAnniversaryYear == 0) {
                System.out.println("Поздравляем с " + years[years.length - 1] + "-летием свадьбы!");
            } else {
                int index = 0;
                for (int i = 0; i < years.length; i++) {
                    if (years[i] == nextAnniversaryYear) {
                        index = i;
                        break;
                    }
                }
                System.out.println("Следующая годовщина свадьбы - " + nextAnniversaryYear + " лет: " + names[index]);
            }
        }
    }
}